DB_USER="postgres"
DB_PASSWORD="postgres"
DB_SERVER_NAME="database-1.cvt1rmfcsluj.ap-southeast-2.rds.amazonaws.com"
DB_DATABASE_NAME="postgres"
